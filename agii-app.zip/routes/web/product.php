<?php

use App\Http\Controllers\ProductController;
use App\Http\Controllers\RealEstateListingController;
use App\Http\Controllers\ReviewController;
use Illuminate\Support\Facades\Route;
use App\Http\Middleware\CheckSubscription;

/*
|--------------------------------------------------------------------------
| PUBLIC ROUTES
|--------------------------------------------------------------------------
*/

// HOME PAGE (optional category filter)
Route::get('/', [ProductController::class, 'index'])->name('home');
Route::get('/home/{category?}', [ProductController::class, 'homeByCategory'])
    ->where('category', '[A-Za-z0-9\-]+')
    ->name('home.category');

Route::middleware(['auth', CheckSubscription::class])->group(function () {
    Route::get('/products/{slug}/edit', [ProductController::class, 'edit'])->name('products.edit');
    Route::put('/products/{slug}', [ProductController::class, 'update'])->name('products.update');
    // Real estate has its own edit form, POST is accepted too in case the form script can't send PUT
    Route::get('/products/{slug}/edit/real-estate', [RealEstateListingController::class, 'edit'])->name('products.edit.real-estate');
    Route::match(['put', 'post'], '/products/{slug}/real-estate', [RealEstateListingController::class, 'update'])->name('products.update.real-estate');
    Route::delete('/products/{slug}', [ProductController::class, 'destroy'])->name('products.destroy');
});

// PRODUCTS LISTING
Route::get('/products', [ProductController::class, 'index'])->name('products.index');
Route::get('/products/{category}', [ProductController::class, 'index'])
    ->where('category', '.*')
    ->name('products.category');

// SINGLE PRODUCT PAGE
Route::get('/product/{slug}', [ProductController::class, 'show'])->name('product.show');

// PRODUCT TRACKING & INQUIRIES
Route::post('/products/track-view', [ProductController::class, 'trackView'])->name('products.track-view');
Route::get('/products/{product}/inquiries-count', [ProductController::class, 'getInquiriesCount'])->name('products.inquiries-count');


Route::get('/boosted-products', [ProductController::class, 'boosted'])->name('products.boosted');

Route::post('/products/{product}/reviews', [ReviewController::class, 'store'])->name('reviews.store');
Route::delete('/reviews/{review}', [ReviewController::class, 'destroy'])->name('reviews.destroy');

// CONTACT SELLER (AUTH REQUIRED)
Route::middleware(['auth'])->post('/products/contact', [ProductController::class, 'storeContact'])
    ->name('contacts.store');


// CONFIRMATION AFTER ADDING PRODUCT
Route::get('/products-added/{id}', [ProductController::class, 'added'])->name('products.added');

// USER HOTELS
Route::get('/user/{user}/hotels', [ProductController::class, 'userHotels'])->name('user.hotels');

/*
|--------------------------------------------------------------------------
| AUTHENTICATED ROUTES (SELLERS)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth'])->group(function () {

    Route::middleware([CheckSubscription::class])->group(function () {
        // CREATE PRODUCT — vendor must be admin-approved before they can list
        Route::middleware(['vendor.approved'])->group(function () {
            // Each listing form (rent, sale) is registered per category slug, before the generic /sell/{type}
            foreach (array_keys(config('listing_forms')) as $slug) {
                Route::get("/sell/{$slug}", [RealEstateListingController::class, 'create'])->defaults('category', $slug)->name("products.create.{$slug}");
                Route::post("/products/{$slug}", [RealEstateListingController::class, 'store'])->defaults('category', $slug)->name("products.store.{$slug}");
            }

            Route::get('/sell/{type}', [ProductController::class, 'create'])->name('products.create');
            Route::post('/products', [ProductController::class, 'store'])->name('products.store');
        });

        
    });

    // AJAX CATEGORY / SPECIFICATION
    Route::get('/categories/{category}/subcategories', [ProductController::class, 'getSubcategories']);
    Route::get('/categories/{category}/specifications', [ProductController::class, 'getSpecifications']);
});

/*
|--------------------------------------------------------------------------
| SERVICE ROUTES
|--------------------------------------------------------------------------
*/
Route::get('/services', [ProductController::class, 'index'])->name('services.index');
Route::get('/services/{category}', [ProductController::class, 'index'])->name('services.category');
