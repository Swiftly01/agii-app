<?php

use App\Http\Middleware\EnsureMarketerIsApproved;
use App\Http\Middleware\EnsureUserHasRole;
use App\Http\Middleware\EnsureUserIsAdmin;
use App\Http\Middleware\EnsureVendorIsApproved;
use App\Http\Middleware\VendorMiddleware;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
         $middleware->alias([
        'vendor.subscription' => VendorMiddleware::class,
        'vendor.approved' => EnsureVendorIsApproved::class,
        'marketer.approved' => EnsureMarketerIsApproved::class,
        'admin' => EnsureUserIsAdmin::class,
        'role' => EnsureUserHasRole::class,
    ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
