<?php
// app/Http/Controllers/ProductController.php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\Location;
use App\Models\Store;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\VendorContact;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    // public function index(Request $request, $category = null)
    // {
    //     // Get categories for navigation
    //     $categories = Category::all();

    //     // Build products query
    //     $productsQuery = Product::with(['user', 'category'])
    //         ->where('status', 'active')
    //         ->whereHas('user', function ($query) {
    //             $query->whereHas('activeSubscription');
    //         });

    //     // Filter by category if provided
    //     if ($category) {
    //         $categoryModel = Category::where('slug', $category)->first();
    //         if ($categoryModel) {
    //             $productsQuery->where('category_id', $categoryModel->id);
    //         }
    //     }

    //     // Handle search
    //     if ($request->has('search')) {
    //         $search = $request->get('search');
    //         $productsQuery->where(function ($query) use ($search) {
    //             $query->where('title', 'like', "%{$search}%")
    //                 ->orWhere('description', 'like', "%{$search}%")
    //                 ->orWhere('tags', 'like', "%{$search}%");
    //         });
    //     }

    //     // Handle sorting
    //     $sort = $request->get('sort', 'latest');
    //     switch ($sort) {
    //         case 'price_low':
    //             $productsQuery->orderBy('price', 'asc');
    //             break;
    //         case 'price_high':
    //             $productsQuery->orderBy('price', 'desc');
    //             break;
    //         case 'rating':
    //             $productsQuery->orderBy('rating', 'desc');
    //             break;
    //         case 'featured':
    //             $productsQuery->where('featured', true)->orderBy('created_at', 'desc');
    //             break;
    //         default:
    //             $productsQuery->orderBy('created_at', 'desc');
    //     }

    //     $products = $productsQuery->paginate(20);

    //     // Get featured stores
    //     $featuredStores = Store::with(['user', 'products'])
    //         ->where('is_active', true)
    //         ->whereHas('user', function ($query) {
    //             $query->whereHas('activeSubscription');
    //         })
    //         ->whereHas('products')
    //         ->inRandomOrder()
    //         ->limit(10)
    //         ->get();

    //     // Get featured products for slider
    //     $featuredProducts = Product::with(['user', 'category'])
    //         ->where('status', 'active')
    //         ->where('featured', true)
    //         ->whereHas('user', function ($query) {
    //             $query->whereHas('activeSubscription');
    //         })
    //         ->orderBy('created_at', 'desc')
    //         ->limit(12)
    //         ->get();

    //     // Get services
    //     $services = Category::where('type', 'service')->with(['services' => function ($query) {
    //         $query->where('is_active', true)
    //             ->whereHas('user', function ($q) {
    //                 $q->whereHas('activeSubscription');
    //             });
    //     }])->get();

    //     return view('welcome', compact('products', 'categories', 'category', 'featuredStores', 'featuredProducts', 'services'));
    // }

    public function index(Request $request, $category = null)
    {
        // Get categories for navigation
        $categories = Category::all();

        // Build products query
        $productsQuery = Product::with(['user', 'category'])
            ->where('status', 'active')
            ->whereHas('user', function ($query) {
                $query->whereHas('activeSubscription');
            });

        // Filter by category if provided
        if ($category) {
            $categoryModel = Category::where('slug', $category)->first();
            if ($categoryModel) {
                $productsQuery->where('category_id', $categoryModel->id);
            }
        }

        // Handle search
        if ($request->has('search')) {
            $search = $request->get('search');
            $productsQuery->where(function ($query) use ($search) {
                $query->where('title', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%")
                    ->orWhere('tags', 'like', "%{$search}%");
            });
        }

        // Handle sorting
        $sort = $request->get('sort', 'latest');
        switch ($sort) {
            case 'price_low':
                $productsQuery->orderBy('price', 'asc');
                break;
            case 'price_high':
                $productsQuery->orderBy('price', 'desc');
                break;
            case 'rating':
                $productsQuery->orderBy('rating', 'desc');
                break;
            case 'featured':
                $productsQuery->where('featured', true)->orderBy('created_at', 'desc');
                break;
            default:
                $productsQuery->orderBy('created_at', 'desc');
        }

        $products = $productsQuery->paginate(20);

        // Get featured stores
        $featuredStores = Store::with(['user', 'products'])
            ->where('is_active', true)
            ->whereHas('user', function ($query) {
                $query->whereHas('activeSubscription');
            })
            ->whereHas('products')
            ->inRandomOrder()
            ->limit(10)
            ->get();

        // Get featured products for slider
        $featuredProducts = Product::with(['user', 'category'])
            ->where('status', 'active')
            ->where('featured', true)
            ->whereHas('user', function ($query) {
                $query->whereHas('activeSubscription');
            })
            ->orderBy('created_at', 'desc')
            ->limit(12)
            ->get();

        // Get service categories and their products
        $serviceCategories = Category::where('type', 'service')->get();

        // Get featured services (products in service categories)
        $featuredServices = Product::with(['user', 'category'])
            ->where('status', 'active')
            ->whereHas('category', function ($query) {
                $query->where('type', 'service');
            })
            ->whereHas('user', function ($query) {
                $query->whereHas('activeSubscription');
            })
            ->orderBy('created_at', 'desc')
            ->limit(12)
            ->get();

        if (request()->is('services*')) {
            return view('services.index', compact(
                'products',
                'categories',
                'category',
                'featuredStores',
                'featuredProducts',
                'featuredServices',
                'serviceCategories'
            ));
        }

        if (request()->is('products*')) {
            return view('products.index', compact(
                'products',
                'categories',
                'category',
                'featuredStores',
                'featuredProducts',
                'featuredServices',
                'serviceCategories'
            ));
        }

        // Default
        return view('welcome', compact(
            'products',
            'categories',
            'category',
            'featuredStores',
            'featuredProducts',
            'featuredServices',
            'serviceCategories'
        ));
    }

    public function show($slug)
    {
        $product = Product::with(['user', 'category'])
            ->where('slug', $slug)
            ->where('status', 'active')
            ->whereHas('user', function ($query) {
                $query->whereHas('activeSubscription');
            })
            ->firstOrFail();

        // Get related products
        $relatedProducts = Product::with(['user', 'category'])
            ->where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->where('status', 'active')
            ->whereHas('user', function ($query) {
                $query->whereHas('activeSubscription');
            })
            ->limit(4)
            ->get();

        return view('products.product-detail', compact('product', 'relatedProducts'));
    }

    public function byCategory($categorySlug)
    {
        $category = Category::where('slug', $categorySlug)->firstOrFail();

        $products = Product::with(['user', 'category'])
            ->where('category_id', $category->id)
            ->where('status', 'active')
            ->whereHas('user', function ($query) {
                $query->whereHas('activeSubscription');
            })
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('products.category', compact('products', 'category'));
    }


    public function trackView(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id'
        ]);

        $product = Product::find($request->product_id);
        $product->incrementViews();

        return response()->json([
            'success' => true,
            'views_count' => $product->views
        ]);
    }

    public function getInquiriesCount($productId)
    {
        $inquiriesCount = VendorContact::where('product_id', $productId)->count();

        return response()->json([
            'success' => true,
            'inquiries_count' => $inquiriesCount
        ]);
    }
    public function storeContact(Request $request)
    {
        $request->validate([
            'vendor_id' => 'required|exists:users,id',
            'product_id' => 'required|exists:products,id',
            'contact_method' => 'required|string|max:50',
            'notes' => 'nullable|string|max:500'
        ]);

        try {
            $vendor = User::findOrFail($request->vendor_id);
            $product = Product::findOrFail($request->product_id);

            // Check if contact already exists for this user today to avoid duplicates
            $existingContact = VendorContact::where('user_id', Auth::id())
                ->where('vendor_id', $vendor->id)
                ->where('product_id', $product->id)
                ->whereDate('contact_date', today())
                ->first();

            if (!$existingContact) {
                VendorContact::create([
                    'user_id' => Auth::id(),
                    'vendor_id' => $vendor->id,
                    'product_id' => $product->id,
                    'vendor_name' => $vendor->business_name ?: $vendor->full_name,
                    'vendor_contact_info' => $this->getVendorContactInfo($vendor, $request->contact_method),
                    'product_name' => $product->title,
                    'contact_date' => now(),
                    'contact_method' => $request->contact_method,
                    'notes' => $request->notes,
                    'status' => 'contacted'
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Contact tracked successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to track contact: ' . $e->getMessage()
            ], 500);
        }
    }

    private function getVendorContactInfo($vendor, $contactMethod)
    {
        if ($contactMethod === 'whatsapp') {
            return $vendor->whatsapp_number ?: $vendor->phone ?: $vendor->email;
        } elseif ($contactMethod === 'phone') {
            return $vendor->phone ?: $vendor->whatsapp_number ?: $vendor->email;
        }

        return $vendor->email ?: $vendor->phone;
    }






    public function create($type)
    {
        // Use the parameter
        $categories = Category::active()
            ->mainCategories()
            ->byType($type) // if you have scopeByType
            ->get();

        return view('products.create', compact('categories', 'type'));
    }



    public function store_users_vendors_me(Request $request, $category = null)
    {
        // Get user's current location (you can get this from request or session)
        $userLat = $request->input('lat'); // or from session: session('user_lat')
        $userLng = $request->input('lng'); // or from session: session('user_lng')

        // If no coordinates in request, try to get from user's profile or use default
        if (!$userLat || !$userLng) {
            $user = Auth::user();
            if ($user && $user->local_government) {
                // Get coordinates from locations table based on user's LGA
                $location = Location::where('lga', $user->local_government)->first();
                if ($location) {
                    $userLat = $location->latitude;
                    $userLng = $location->longitude;
                }
            }

            // Fallback to a default location (e.g., Lagos)
            if (!$userLat || !$userLng) {
                $userLat = 6.5244;
                $userLng = 3.3792;
            }
        }

        // Get vendors in the same local government area
        $vendors = User::where('user_type', 'vendor')
            ->where('local_government', Auth::user()->local_government ?? 'Damban')
            ->where('status', 'active')
            ->get();

        // Calculate distances and get nearby vendors
        $nearbyVendors = $this->getNearbyVendors($vendors, $userLat, $userLng);

        // Get products from nearby vendors
        $vendorIds = $nearbyVendors->pluck('id')->toArray();

        $productsQuery = Product::whereIn('user_id', $vendorIds)
            ->where('status', 'active');

        // Filter by category if provided
        if ($category) {
            $categoryModel = Category::where('slug', $category)->first();
            if ($categoryModel) {
                $productsQuery->where('category_id', $categoryModel->id);
            }
        }

        $products = $productsQuery->with(['user', 'category'])
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        // Get categories for filter
        $categories = Category::where('status', 'active')
            ->orderBy('name')
            ->get();

        // Featured items
        $featuredStores = User::where('user_type', 'vendor')
            ->where('status', 'active')
            ->where('featured', true)
            ->limit(6)
            ->get();

        $featuredProducts = Product::where('status', 'active')
            ->where('featured', true)
            ->limit(8)
            ->get();

        return view('store', compact(
            'products',
            'categories',
            'category',
            'featuredStores',
            'featuredProducts',
            'nearbyVendors',
            'userLat',
            'userLng'
        ));
    }

    public function store_users_vendors_me_spatial(Request $request, $category = null)
    {
        $userLat = $request->input('lat', 6.5244);
        $userLng = $request->input('lng', 3.3792);
        $radiusKm = 50; // Search radius in kilometers

        // Get nearby vendors using spatial query
        $nearbyVendors = User::select('users.*')
            ->join('locations', 'locations.lga', '=', 'users.local_government')
            ->where('users.user_type', 'vendor')
            ->where('users.status', 'active')
            ->whereRaw("
            (6371 * acos(cos(radians(?)) * cos(radians(locations.latitude)) *
            cos(radians(locations.longitude) - radians(?)) +
            sin(radians(?)) * sin(radians(locations.latitude)))) <= ?
        ", [$userLat, $userLng, $userLat, $radiusKm])
            ->with(['products' => function ($query) {
                $query->where('status', 'active');
            }])
            ->get()
            ->each(function ($vendor) use ($userLat, $userLng) {
                // Calculate distance for each vendor
                $vendorLocation = Location::where('lga', $vendor->local_government)->first();
                if ($vendorLocation) {
                    $vendor->distance = round($this->calculateDistance(
                        $userLat,
                        $userLng,
                        $vendorLocation->latitude,
                        $vendorLocation->longitude
                    ), 2);
                    $vendor->distance_unit = 'km';
                }
            })
            ->sortBy('distance');

        // Get products from nearby vendors
        $vendorIds = $nearbyVendors->pluck('id')->toArray();

        $productsQuery = Product::whereIn('user_id', $vendorIds)
            ->where('status', 'active');

        if ($category) {
            $categoryModel = Category::where('slug', $category)->first();
            if ($categoryModel) {
                $productsQuery->where('category_id', $categoryModel->id);
            }
        }

        $products = $productsQuery->with(['user', 'category'])
            ->orderBy('created_at', 'desc')
            ->paginate(12);

        $categories = Category::where('status', 'active')->get();
        $featuredStores = User::where('user_type', 'vendor')->where('featured', true)->limit(6)->get();
        $featuredProducts = Product::where('featured', true)->limit(8)->get();

        return view('store', compact(
            'products',
            'categories',
            'category',
            'featuredStores',
            'featuredProducts',
            'nearbyVendors',
            'userLat',
            'userLng'
        ));
    }

    /**
     * Calculate distances and get nearby vendors
     */
    private function getNearbyVendors($vendors, $userLat, $userLng, $radiusKm = 50)
    {
        $nearbyVendors = collect();

        foreach ($vendors as $vendor) {
            // Get vendor's location coordinates
            $vendorLocation = Location::where('lga', $vendor->local_government)->first();

            if ($vendorLocation && $vendorLocation->latitude && $vendorLocation->longitude) {
                $distance = $this->calculateDistance(
                    $userLat,
                    $userLng,
                    $vendorLocation->latitude,
                    $vendorLocation->longitude
                );

                // Add distance to vendor object
                $vendor->distance = round($distance, 2);
                $vendor->distance_unit = 'km';

                if ($distance <= $radiusKm) {
                    $nearbyVendors->push($vendor);
                }
            }
        }

        // Sort by distance (nearest first)
        return $nearbyVendors->sortBy('distance');
    }

    /**
     * Calculate distance between two coordinates using Haversine formula
     */
    private function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371; // Earth's radius in kilometers

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat / 2) * sin($dLat / 2) +
            cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
            sin($dLon / 2) * sin($dLon / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c;
    }




































    // public function store(Request $request)
    // {
    //     // Debug: Check what's being received
    //     Log::info('Product Store Request:', $request->all());
    //     Log::info('Specifications received:', ['specifications' => $request->specifications]);



    //     $validated = $request->validate([
    //         'title' => 'required|string|max:255',
    //         'category_id' => 'required|exists:categories,id',
    //         'description' => 'required|string',
    //         'price' => 'required|numeric|min:0',
    //         'old_price' => 'nullable|numeric|min:0',
    //         'condition' => 'required|in:new,used_like_new,used_good,used_fair',
    //         'location' => 'required|string|max:255',
    //         'quantity' => 'required|integer|min:1',
    //         'images' => 'required|array|min:1|max:10',
    //         'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:5120', // 5MB max
    //         'specifications' => 'nullable|array',
    //         'negotiable' => 'boolean',
    //         'tags' => 'nullable|array',
    //     ]);

    //     try {
    //         // Handle image uploads
    //         $imagePaths = [];
    //         if ($request->hasFile('images')) {
    //             foreach ($request->file('images') as $image) {
    //                 $path = $image->store('products', 'public');
    //                 $imagePaths[] = $path;
    //             }
    //         }

    //         // Generate slug
    //         $slug = $this->generateUniqueSlug($request->title);

    //         // Handle specifications - ensure it's properly formatted
    //         $specifications = [];
    //         if ($request->has('specifications')) {
    //             // If specifications is already an array, use it directly
    //             if (is_array($request->specifications)) {
    //                 $specifications = $request->specifications;
    //             }
    //             // If it's a JSON string, decode it
    //             elseif (is_string($request->specifications)) {
    //                 $specifications = json_decode($request->specifications, true) ?? [];
    //             }

    //             // Remove any empty values
    //             $specifications = array_filter($specifications, function ($value) {
    //                 return !empty($value) && $value !== '';
    //             });
    //         }

    //         Log::info('Processed specifications:', $specifications);

    //         // Create product
    //         $product = Product::create([
    //             'user_id' => Auth::id(),
    //             'category_id' => $request->category_id,
    //             'title' => $request->title,
    //             'slug' => $slug,
    //             'description' => $request->description,
    //             'price' => $request->price,
    //             'old_price' => $request->old_price,
    //             'condition' => $request->condition,
    //             'location' => $request->location,
    //             'quantity' => $request->quantity,
    //             'images' => $imagePaths,
    //             'specifications' => $specifications, // This should now be a proper array
    //             'negotiable' => $request->boolean('negotiable'),
    //             'tags' => $request->tags ?? [],
    //             'status' => 'active',
    //             'meta_title' => $request->title,
    //             'meta_description' => Str::limit($request->description, 160),
    //         ]);

    //         return response()->json([
    //             'success' => true,
    //             'message' => 'Product listed successfully!',
    //             'product' => $product,
    //             'redirect_url' => route('products.added', $product->id)
    //         ]);
    //     } catch (\Exception $e) {
    //         Log::error('Product creation error: ' . $e->getMessage());
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Error creating product: ' . $e->getMessage()
    //         ], 500);
    //     }
    // }



    public function store(Request $request)
    {
        // Debug: Check what's being received
        Log::info('Product Store Request:', $request->all());

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'old_price' => 'nullable|numeric|min:0',
            'condition' => 'required|in:new,used_like_new,used_good,used_fair',
            'location' => 'required|string|max:255',
            'quantity' => 'required|integer|min:1',
            'images' => 'required|array|min:1|max:10',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif,webp|max:5120',
            'specifications' => 'nullable',
            'negotiable' => 'boolean',
        ]);

        try {
            // Handle image uploads - store in public/product-images directory
            $imagePaths = [];
            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $image) {
                    // Create directory if it doesn't exist
                    $directory = public_path('product-images');
                    if (!file_exists($directory)) {
                        mkdir($directory, 0755, true);
                    }

                    // Generate unique filename
                    $filename = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();

                    // Move image to public/product-images directory
                    $image->move($directory, $filename);

                    // Store relative path for database
                    $imagePaths[] = 'product-images/' . $filename;
                }
            }

            // Generate slug
            $slug = $this->generateUniqueSlug($request->title);

            // Handle specifications
            $specifications = [];
            if ($request->has('specifications') && is_array($request->specifications)) {
                $specifications = array_filter($request->specifications, function ($value) {
                    return !empty($value) && $value !== '';
                });
            }
            $user = Auth::user();

            $storeId = $user->store ? $user->store->id : null;

            // Create product
            $product = Product::create([
                'user_id' => Auth::id(),
                'store_id' => $storeId,
                'category_id' => $request->category_id,
                'title' => $request->title,
                'slug' => $slug,
                'description' => $request->description,
                'price' => $request->price,
                'old_price' => $request->old_price,
                'condition' => $request->condition,
                'location' => $request->location,
                'quantity' => $request->quantity,
                'images' => $imagePaths,
                'specifications' => $specifications,
                'negotiable' => $request->boolean('negotiable'),
                'tags' => $request->tags ?? [],
                'status' => 'active',
                'meta_title' => $request->title,
                'meta_description' => Str::limit($request->description, 160),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Product listed successfully!',
                'product' => $product,
                'redirect_url' => route('products.added', $product->id)
            ]);
        } catch (\Exception $e) {
            Log::error('Product creation error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error creating product: ' . $e->getMessage()
            ], 500);
        }
    }
    public function added($id)
    {
        $product = Product::with(['user', 'category'])->findOrFail($id);
        return view('products.show', compact('product'));
    }


    public function getSubcategories($categoryId)
    {
        $category = Category::findOrFail($categoryId);
        $subcategories = $category->children()->active()->get();

        return response()->json([
            'success' => true,
            'subcategories' => $subcategories,
            'specification_fields' => $category->getSpecificationFields()
        ]);
    }


    public function getSpecifications($categoryId)
    {
        $category = Category::findOrFail($categoryId);

        // Get specification fields for the category
        $specificationFields = $category->getSpecificationFields();

        return response()->json([
            'success' => true,
            'fields' => $specificationFields
        ]);
    }
    private function generateUniqueSlug($title)
    {
        $slug = Str::slug($title);
        $count = Product::where('slug', 'LIKE', "{$slug}%")->count();
        return $count ? "{$slug}-{$count}" : $slug;
    }


    public function edit($slug)
    {
        $product = Product::where('slug', $slug)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        $categories = Category::active()->mainCategories()->get();

        return view('products.edit', compact('product', 'categories'));
    }

    public function update(Request $request, $slug)
    {
        $product = Product::where('slug', $slug)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'old_price' => 'nullable|numeric|min:0',
            'condition' => 'required|in:new,used_like_new,used_good,used_fair',
            'location' => 'required|string|max:255',
            'quantity' => 'required|integer|min:1',
            'images' => 'sometimes|array|min:1|max:10',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif,webp|max:5120',
            'specifications' => 'nullable',
            'negotiable' => 'boolean',
            'status' => 'required|in:active,inactive,pending',
        ]);

        try {
            // Handle image uploads if new images are provided
            $imagePaths = $product->images ?? [];

            if ($request->hasFile('images')) {
                // Delete old images
                foreach ($product->images as $oldImage) {
                    $oldImagePath = public_path($oldImage);
                    if (file_exists($oldImagePath)) {
                        unlink($oldImagePath);
                    }
                }

                // Upload new images
                $imagePaths = [];
                foreach ($request->file('images') as $image) {
                    $directory = public_path('product-images');
                    if (!file_exists($directory)) {
                        mkdir($directory, 0755, true);
                    }

                    $filename = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
                    $image->move($directory, $filename);
                    $imagePaths[] = 'product-images/' . $filename;
                }
            }

            // Handle specifications
            $specifications = [];
            if ($request->has('specifications') && is_array($request->specifications)) {
                $specifications = array_filter($request->specifications, function ($value) {
                    return !empty($value) && $value !== '';
                });
            }

            // Generate new slug if title changed
            $newSlug = $product->slug;
            if ($request->title !== $product->title) {
                $newSlug = $this->generateUniqueSlug($request->title);
            }

            $user = Auth::user();
            $storeId = $user->store ? $user->store->id : null;

            // Update product
            $product->update([
                'category_id' => $request->category_id,
                'store_id' => $storeId,
                'title' => $request->title,
                'slug' => $newSlug,
                'description' => $request->description,
                'price' => $request->price,
                'old_price' => $request->old_price,
                'condition' => $request->condition,
                'location' => $request->location,
                'quantity' => $request->quantity,
                'images' => $imagePaths,
                'specifications' => $specifications,
                'negotiable' => $request->boolean('negotiable'),
                'status' => $request->status,
                'meta_title' => $request->title,
                'meta_description' => Str::limit($request->description, 160),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Product updated successfully!',
                'product' => $product,
                'redirect_url' => route('products.added', $product->id)
            ]);
        } catch (\Exception $e) {
            Log::error('Product update error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error updating product: ' . $e->getMessage()
            ], 500);
        }
    }

    public function destroy($slug)
    {
        try {
            $product = Product::where('slug', $slug)
                ->where('user_id', Auth::id())
                ->firstOrFail();

            // Delete associated images
            foreach ($product->images as $image) {
                $imagePath = public_path($image);
                if (file_exists($imagePath)) {
                    unlink($imagePath);
                }
            }

            $product->delete();

            // return response()->json([
            //     'success' => true,
            //     'message' => 'Product deleted successfully!',
            //     'redirect_url' => route('vendor.dashboard')
            // ]);

            return redirect()->back()->with('success', 'Product deleted successfully!');
        } catch (\Exception $e) {
            Log::error('Product deletion error: ' . $e->getMessage());

            return redirect()->back()->with('error', 'Error deleting product: ' . $e->getMessage());
            // return response()->json([
            //     'success' => false,
            //     'message' => 'Error deleting product: ' . $e->getMessage()
            // ], 500);
        }
    }
}
