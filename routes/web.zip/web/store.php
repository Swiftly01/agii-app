<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\StoreController;

// Store Routes
Route::middleware(['auth'])->group(function () {
    Route::get('/stores/create', [StoreController::class, 'create'])->name('stores.create');
    Route::post('/stores-creating', [StoreController::class, 'store'])->name('stores.store');
    Route::get('/stores/{store}/edit', [StoreController::class, 'edit'])->name('stores.edit');
    Route::put('/stores/{store}', [StoreController::class, 'update'])->name('stores.update');
    Route::get('/stores/{store}', [StoreController::class, 'show'])->name('stores.show');
});


Route::get('store', function () {
    dd('eeee');
});


Route::get('stores', [StoreController::class, 'index'])->name('stores.index');
Route::get('stores/{slug}', [StoreController::class, 'show'])->name('stores.show');
