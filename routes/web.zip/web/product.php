<?php

use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;
use App\Http\Middleware\CheckSubscription;

/*
|--------------------------------------------------------------------------
| PUBLIC ROUTES
|--------------------------------------------------------------------------
*/

// Home → Products listing
Route::get('/', [ProductController::class, 'index'])->name(name: 'products');

// Single product page
Route::get('/product/{slug}', [ProductController::class, 'show'])
    ->name('product.show');


// Track product view
Route::post('/products/track-view', [ProductController::class, 'trackView'])
    ->name('products.track-view');

// Inquiries count (use product id here)
Route::get('/products/{product}/inquiries-count', [ProductController::class, 'getInquiriesCount'])
    ->name('products.inquiries-count');

// Contact seller
Route::post('/products/contact', [ProductController::class, 'storeContact'])
    ->name('contacts.store');

// After product added confirmation
Route::get('/products-added/{id}', [ProductController::class, 'added'])
    ->name('products.added');


/*
|--------------------------------------------------------------------------
| AUTHENTICATED ROUTES (FOR SELLERS)
|--------------------------------------------------------------------------
*/

Route::middleware(['auth'])->group(function () {

    // Product routes with subscription check
    Route::middleware([CheckSubscription::class])->group(function () {
        // Seller product creation page
        Route::get('/sell/{type}', [ProductController::class, 'create'])
            ->name('products.create');

        // Store product
        Route::post('/products', [ProductController::class, 'store'])
            ->name('products.store');

        /*
        |--------------------------------------------------------------------------
        | EDIT / UPDATE / DELETE
        | MUST come BEFORE the category route to avoid route swallowing
        |--------------------------------------------------------------------------
        */

        Route::get('/products/{slug}/edit', [ProductController::class, 'edit'])
            ->name('products.edit');

        Route::put('/products/{slug}', [ProductController::class, 'update'])
            ->name('products.update');

        Route::delete('/products/{slug}', [ProductController::class, 'destroy'])
            ->name('products.destroy');
    });

    // Ajax routes (no subscription check needed)
    Route::get('/categories/{category}/subcategories', [ProductController::class, 'getSubcategories']);
    Route::get('/categories/{category}/specifications', [ProductController::class, 'getSpecifications']);
});


/*
|--------------------------------------------------------------------------
| PUBLIC PRODUCT LISTING (MUST BE LAST)
|--------------------------------------------------------------------------
*/

Route::get('/products/{category?}', [ProductController::class, 'index'])
    ->where('category', '.*')
    ->name('products.index');


// Service routes (reuse the same index method)
Route::get('/services', [ProductController::class, 'index'])->name('services.index');
Route::get('/services/{category}', [ProductController::class, 'index'])->name('services.category');
