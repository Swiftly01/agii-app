<?php

use Illuminate\Support\Facades\Route;
use App\Helpers\Routes\RouteHelper;
// routes/web.php

use App\Http\Controllers\StoreController;
use App\Http\Controllers\ProfileController;

RouteHelper::includeRouteFiles(__DIR__ . '/web');


Route::get('/test', function () {
    return view('layout.store');
});


// use App\Http\Controllers\StoreController;

// Store Routes
Route::middleware(['auth'])->group(function () {
    Route::get('/stores/create', [StoreController::class, 'create'])->name('stores.create');
    Route::post('/stores', [StoreController::class, 'store'])->name('stores.store');
    Route::get('/stores/{store}/edit', [StoreController::class, 'edit'])->name('stores.edit');
    Route::put('/stores/{store}', [StoreController::class, 'update'])->name('stores.update');
    Route::get('/stores/{store}', [StoreController::class, 'show'])->name('stores.show');
});


Route::get('stores', [StoreController::class, 'index'])->name('stores.index');
Route::get('stores/{slug}', [StoreController::class, 'show'])->name('stores.show');


// routes/web.php
Route::middleware(['auth'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
});


use Illuminate\Support\Facades\Mail;

Route::get('/test-mail', function () {
    $details = [
        'title' => 'Test Email from Laravel',
        'body' => 'This is a test email to check SMTP configuration.'
    ];

    Mail::raw($details['body'], function ($message) use ($details) {
        $message->to('agiidynastyltd@gmail.com')
            ->subject($details['title']);
    });

    return 'Test email sent!';
});
